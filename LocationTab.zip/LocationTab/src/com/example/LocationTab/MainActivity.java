package com.example.LocationTab;

import com.example.LocationTab.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class MainActivity extends TabActivity {
	TabHost tabhost;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabhost = this.getTabHost();
        
        Drawable listicon = this.getResources().getDrawable(R.drawable.mylocation);
        Drawable addlocationicon = this.getResources().getDrawable(R.drawable.add);
        Drawable profileicon = this.getResources().getDrawable(R.drawable.icon22);
        
        Intent intentL = new Intent(this,LocationList.class);
        Intent intentA = new Intent(this,AddLocation.class);
        Intent intentAb = new Intent(this,MyProfile.class);
        
        TabSpec locationlist = tabhost.newTabSpec("locationlist");
        	locationlist.setIndicator("", listicon);
        	locationlist.setContent(intentL);
        	
        TabSpec addlocation = tabhost.newTabSpec("addlocation");	
        	addlocation.setIndicator("", addlocationicon);
        	addlocation.setContent(intentA);
        	
        TabSpec myprofile = tabhost.newTabSpec("myprofile");
        	myprofile.setIndicator("", profileicon);
        	myprofile.setContent(intentAb);	
        	 
        	
        tabhost.addTab(locationlist);	
        tabhost.addTab(addlocation);
        tabhost.addTab(myprofile);
        
        
    }
		
    
}
